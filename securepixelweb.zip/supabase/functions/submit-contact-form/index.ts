Deno.serve(async (req) => {
    const corsHeaders = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
        'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE, PATCH',
        'Access-Control-Max-Age': '86400',
        'Access-Control-Allow-Credentials': 'false'
    };

    if (req.method === 'OPTIONS') {
        return new Response(null, { status: 200, headers: corsHeaders });
    }

    try {
        const { name, email, phone, subject, message } = await req.json();

        console.log('Contact form submission received:', { name, email, subject });

        // Validate required fields
        if (!name || name.trim().length === 0) {
            throw new Error('Name is required');
        }

        if (!email || email.trim().length === 0) {
            throw new Error('Email is required');
        }

        if (!message || message.trim().length === 0) {
            throw new Error('Message is required');
        }

        // Basic email validation
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            throw new Error('Please provide a valid email address');
        }

        // Get environment variables
        const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
        const supabaseUrl = Deno.env.get('SUPABASE_URL');

        if (!serviceRoleKey || !supabaseUrl) {
            throw new Error('Supabase configuration missing');
        }

        console.log('Saving contact form to database...');

        // Save contact form to database
        const contactFormData = {
            name: name.trim(),
            email: email.trim().toLowerCase(),
            phone: phone ? phone.trim() : null,
            subject: subject ? subject.trim() : null,
            message: message.trim(),
            status: 'new',
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString()
        };

        const contactResponse = await fetch(`${supabaseUrl}/rest/v1/contact_forms`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey,
                'Content-Type': 'application/json',
                'Prefer': 'return=representation'
            },
            body: JSON.stringify(contactFormData)
        });

        if (!contactResponse.ok) {
            const errorText = await contactResponse.text();
            console.error('Failed to save contact form:', errorText);
            throw new Error(`Failed to save contact form: ${errorText}`);
        }

        const savedForm = await contactResponse.json();
        console.log('Contact form saved successfully:', savedForm[0].id);

        const result = {
            data: {
                id: savedForm[0].id,
                message: 'Contact form submitted successfully. We will get back to you soon!',
                status: 'success'
            }
        };

        console.log('Contact form submission completed successfully');

        return new Response(JSON.stringify(result), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });

    } catch (error) {
        console.error('Contact form submission error:', error);

        const errorResponse = {
            error: {
                code: 'CONTACT_FORM_FAILED',
                message: error.message,
                timestamp: new Date().toISOString()
            }
        };

        return new Response(JSON.stringify(errorResponse), {
            status: 400,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
    }
});