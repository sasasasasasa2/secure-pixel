Deno.serve(async (req) => {
    const corsHeaders = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
        'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE, PATCH',
        'Access-Control-Max-Age': '86400',
        'Access-Control-Allow-Credentials': 'false'
    };

    if (req.method === 'OPTIONS') {
        return new Response(null, { status: 200, headers: corsHeaders });
    }

    try {
        const { paymentIntentId } = await req.json();

        console.log('Payment confirmation request received:', { paymentIntentId });

        if (!paymentIntentId) {
            throw new Error('Payment intent ID is required');
        }

        // Get environment variables
        const stripeSecretKey = Deno.env.get('STRIPE_SECRET_KEY');
        const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
        const supabaseUrl = Deno.env.get('SUPABASE_URL');

        if (!stripeSecretKey) {
            throw new Error('Stripe secret key not configured');
        }

        if (!serviceRoleKey || !supabaseUrl) {
            throw new Error('Supabase configuration missing');
        }

        console.log('Retrieving payment intent from Stripe...');

        // Get payment intent from Stripe to verify status
        const stripeResponse = await fetch(`https://api.stripe.com/v1/payment_intents/${paymentIntentId}`, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${stripeSecretKey}`
            }
        });

        if (!stripeResponse.ok) {
            const errorData = await stripeResponse.text();
            console.error('Stripe API error:', errorData);
            throw new Error(`Failed to retrieve payment intent: ${errorData}`);
        }

        const paymentIntent = await stripeResponse.json();
        console.log('Payment intent status:', paymentIntent.status);

        // Find the order in our database
        const orderResponse = await fetch(`${supabaseUrl}/rest/v1/orders?stripe_payment_intent_id=eq.${paymentIntentId}`, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey,
                'Content-Type': 'application/json'
            }
        });

        if (!orderResponse.ok) {
            const errorText = await orderResponse.text();
            throw new Error(`Failed to find order: ${errorText}`);
        }

        const orders = await orderResponse.json();
        if (!orders || orders.length === 0) {
            throw new Error('Order not found');
        }

        const order = orders[0];
        console.log('Found order:', order.id);

        // Determine new order status based on payment intent status
        let newStatus = 'pending';
        if (paymentIntent.status === 'succeeded') {
            newStatus = 'confirmed';
        } else if (paymentIntent.status === 'canceled' || paymentIntent.status === 'payment_failed') {
            newStatus = 'failed';
        } else if (paymentIntent.status === 'processing') {
            newStatus = 'processing';
        }

        console.log('Updating order status to:', newStatus);

        // Update order status
        const updateResponse = await fetch(`${supabaseUrl}/rest/v1/orders?id=eq.${order.id}`, {
            method: 'PATCH',
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey,
                'Content-Type': 'application/json',
                'Prefer': 'return=representation'
            },
            body: JSON.stringify({
                status: newStatus,
                updated_at: new Date().toISOString()
            })
        });

        if (!updateResponse.ok) {
            const errorText = await updateResponse.text();
            throw new Error(`Failed to update order: ${errorText}`);
        }

        const updatedOrder = await updateResponse.json();
        console.log('Order updated successfully');

        // Get order items for the response
        const itemsResponse = await fetch(`${supabaseUrl}/rest/v1/order_items?order_id=eq.${order.id}`, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey,
                'Content-Type': 'application/json'
            }
        });

        const orderItems = itemsResponse.ok ? await itemsResponse.json() : [];

        const result = {
            data: {
                order: updatedOrder[0],
                orderItems: orderItems,
                paymentStatus: paymentIntent.status,
                paymentIntent: {
                    id: paymentIntent.id,
                    status: paymentIntent.status,
                    amount: paymentIntent.amount,
                    currency: paymentIntent.currency
                }
            }
        };

        console.log('Payment confirmation completed successfully');

        return new Response(JSON.stringify(result), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });

    } catch (error) {
        console.error('Payment confirmation error:', error);

        const errorResponse = {
            error: {
                code: 'PAYMENT_CONFIRMATION_FAILED',
                message: error.message,
                timestamp: new Date().toISOString()
            }
        };

        return new Response(JSON.stringify(errorResponse), {
            status: 500,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
    }
});