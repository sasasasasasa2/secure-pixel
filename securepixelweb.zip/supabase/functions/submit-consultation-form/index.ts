Deno.serve(async (req) => {
    const corsHeaders = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
        'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE, PATCH',
        'Access-Control-Max-Age': '86400',
        'Access-Control-Allow-Credentials': 'false'
    };

    if (req.method === 'OPTIONS') {
        return new Response(null, { status: 200, headers: corsHeaders });
    }

    try {
        const { 
            fullName, 
            company, 
            profession, 
            corporateEmail, 
            phone, 
            deviceQuantity, 
            budgetRange, 
            paymentMethod, 
            deliveryCity, 
            additionalComments 
        } = await req.json();

        console.log('Consultation form submission received:', { fullName, company, corporateEmail });

        // Validate required fields
        if (!fullName || fullName.trim().length === 0) {
            throw new Error('El nombre completo es requerido');
        }

        if (!company || company.trim().length === 0) {
            throw new Error('La empresa/organización es requerida');
        }

        if (!profession || profession.trim().length === 0) {
            throw new Error('La profesión es requerida');
        }

        if (!corporateEmail || corporateEmail.trim().length === 0) {
            throw new Error('El email corporativo es requerido');
        }

        if (!phone || phone.trim().length === 0) {
            throw new Error('El teléfono es requerido');
        }

        if (!deviceQuantity) {
            throw new Error('La cantidad de dispositivos es requerida');
        }

        if (!budgetRange) {
            throw new Error('El rango de presupuesto es requerido');
        }

        if (!paymentMethod) {
            throw new Error('El método de pago es requerido');
        }

        if (!deliveryCity || deliveryCity.trim().length === 0) {
            throw new Error('La ciudad de entrega es requerida');
        }

        // Basic email validation
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(corporateEmail)) {
            throw new Error('Por favor proporciona un email corporativo válido');
        }

        // Get environment variables
        const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
        const supabaseUrl = Deno.env.get('SUPABASE_URL');

        if (!serviceRoleKey || !supabaseUrl) {
            throw new Error('Supabase configuration missing');
        }

        console.log('Saving consultation to database...');

        // Save consultation to database - reusing contact_forms table with adapted fields
        const consultationData = {
            name: fullName.trim(),
            email: corporateEmail.trim().toLowerCase(),
            phone: phone.trim(),
            subject: `Consulta empresarial - ${company.trim()}`,
            message: `CONSULTA EMPRESARIAL\n\nEmpresa/Organización: ${company.trim()}\nProfesión: ${profession.trim()}\nCantidad de dispositivos: ${deviceQuantity}\nPresupuesto aproximado: ${budgetRange}\nMétodo de pago preferido: ${paymentMethod}\nCiudad de entrega: ${deliveryCity.trim()}\n\nComentarios adicionales:\n${additionalComments ? additionalComments.trim() : 'Ninguno'}`,
            status: 'new',
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString()
        };

        const consultationResponse = await fetch(`${supabaseUrl}/rest/v1/contact_forms`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey,
                'Content-Type': 'application/json',
                'Prefer': 'return=representation'
            },
            body: JSON.stringify(consultationData)
        });

        if (!consultationResponse.ok) {
            const errorText = await consultationResponse.text();
            console.error('Failed to save consultation:', errorText);
            throw new Error(`Failed to save consultation: ${errorText}`);
        }

        const savedConsultation = await consultationResponse.json();
        console.log('Consultation saved successfully:', savedConsultation[0].id);

        const result = {
            data: {
                id: savedConsultation[0].id,
                message: 'Consulta enviada correctamente. Nuestro equipo comercial se pondrá en contacto contigo en un plazo máximo de 24 horas para proporcionarte una propuesta personalizada.',
                status: 'success'
            }
        };

        console.log('Consultation submission completed successfully');

        return new Response(JSON.stringify(result), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });

    } catch (error) {
        console.error('Consultation submission error:', error);

        const errorResponse = {
            error: {
                code: 'CONSULTATION_FAILED',
                message: error.message,
                timestamp: new Date().toISOString()
            }
        };

        return new Response(JSON.stringify(errorResponse), {
            status: 400,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
    }
});